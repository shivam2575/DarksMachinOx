const express=require('express');
const ejs=require('ejs');
const Nexmo=require('nexmo');
const bodyParser=require('body-parser');
const socketio=require('socket.io');
const path=require('path');
const sendMail = require('./mail')
const PORT = 3000;
const app = express();

//initilizing nexmo
const nexmo = new Nexmo({
  apiKey: 'd01cdd81',
  apiSecret: 'TjBKS56NEamYUimx'
}, {debug: true} )




//using static files (css, images etc...)
app.use(express.static('public'));


//parsing data
app.use(express.urlencoded({extended: false}));

app.use(express.json());


//mail post method
app.post('/email', (req,res) =>{

  const {name, email , subject, text} = req.body;
  console.log('Data: ' ,req.body);

  sendMail(name, email, subject, text, function(err,data){
    if(err){
      res.status(500).json({message: "Internal error"});
    } else{
      res.json({message: "Email sent"});
    }

  });

});


//sms post method
app.post('/', (req,res) => {
  const number = req.body.number;
  const text= req.body.number;

  nexmo.message.sendSms(

    'Vonage APIs', '916354956322', text,

    (err,responseData) => {
      if(err){
        console.log(err);
      } else{
        console.dir(responseData);
      }
    }
  );
});


//rendering contact page
app.get('/contact',(req,res) => {
    res.sendFile(path.join(__dirname,'views','contact.html'));
})



//rendering home page
app.get('/',(req,res)=>{

  res.sendFile(path.join(__dirname ,'views', 'home.html'));

});



//starting server
app.listen(PORT, () => console.log("Server started at port ", PORT));



//connect to socket.io
